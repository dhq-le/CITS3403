from flask import Flask, request, session, redirect, url_for, render_template_string

app = Flask(__name__)
app.secret_key = 'tamenchaoworengbaba,wonababazuodanta'

USER_DATA = {
    'username': 'testuser',
    'password': '123456'
}

login_template = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Login</title>
    <style>
        body {
            background-color: azure;
            font-family: Arial, sans-serif;
            color: black;
            margin: 0;
            padding: 0;
        }
        .logo-container {
            text-align: center;
            margin-top: 170px;
        }
        .logo {
            width: 150px;
            height: 150px;
            object-fit: contain;
        }
        .navbar {
            background-color: gainsboro;
            padding: 10px;
            text-align: center;
            font-weight: bold;
        }
        .login-box {
            max-width: 300px;
            margin: 40px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .login-box h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 8px;
            border: 1px solid darkgrey;
            box-sizing: border-box;
        }
        .btn-submit {
            width: 100%;
            padding: 10px;
            background-color: deepskyblue;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-submit:hover {
            background-color: #00a3dd;
        }
        .error {
            color: red;
            text-align: center;
            margin-bottom: 10px;
        }
        .success {
            color: green;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="logo-container">
        <img src="static/logo.jpg" alt="Logo" class="logo">
    </div>
    <div class="login-box">
        <h1>Login</h1>
        {% if error %}
            <div class="error">{{ error }}</div>
        {% endif %}
        <form method="POST" action="{{ url_for('login') }}">
            <div class="form-group">
                <label>Username:</label>
                <input type="text" name="username" required>
            </div>
            <div class="form-group">
                <label>Password:</label>
                <input type="password" name="password" required>
            </div>
            <button type="submit" class="btn-submit">Login</button>
        </form>
    </div>
</body>
</html>
"""



@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template_string(login_template)
    username = request.form.get('username')
    password = request.form.get('password')
    if username == USER_DATA['username'] and password == USER_DATA['password']:
        session['logged_in'] = True
        session['username'] = username
        return redirect(url_for('welcome'))
    else:
        return render_template_string(login_template, error="Username or Password Wrong")

@app.route('/welcome')
def welcome():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return f"<div class='success'>Welcome，{session.get('username')}！</div>"

@app.route('/logout')
def logout():
    session.clear()
    return "Logout.<a href='/login'>ReLogin</a>"

if __name__ == '__main__':
    app.run(debug=True)
